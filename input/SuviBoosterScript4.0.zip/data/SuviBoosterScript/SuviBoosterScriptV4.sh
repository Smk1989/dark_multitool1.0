#!/system/bin/sh
#A110 performance booster script by bsuhas. 
#Users are free to use this but ROM developers please DO NOT include this in your ROM
#Dont forget to say thanks to bsuhas here http://forum.xda-developers.com/showthread.php?t=2499051

GOVERNOR_CPU1_FILE="/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor";
#GOVERNOR_CPU2_FILE="/sys/devices/system/cpu/cpu1/cpufreq/scaling_governor";
MAX_FREQ_CPU1_FILE="/sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq";
#MAX_FREQ_CPU2_FILE="/sys/devices/system/cpu/cpu1/cpufreq/scaling_max_freq";
MIN_FREQ_CPU1_FILE="/sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq";
#MIN_FREQ_CPU2_FILE="/sys/devices/system/cpu/cpu1/cpufreq/scaling_min_freq";
SECOND_CORE_FILE="/sys/devices/system/cpu/cpu1/online";
ADJ_PARAMS_FILE="/sys/module/lowmemorykiller/parameters/adj";
MINFREE_FILE="/sys/module/lowmemorykiller/parameters/minfree";
AWAKE_STATE_FILE="/sys/power/wait_for_fb_wake";
SLEEP_STATE_FILE="/sys/power/wait_for_fb_sleep";
MMC_FILES="/sys/block/mmc*";
BDI_FILES="/sys/devices/virtual/bdi/*";

BATTERY_STATE_FILE="/sys/class/power_supply/battery/status";
BATTERY_CAPACITY_FILE="/sys/class/power_supply/battery/capacity";
BATTERY_STATE_CHARGING="Charging";
BATTERY_STATE_DISCHARGING="Not charging";

SUVI_BASE_DIR="/data/SuviBoosterScript/";
LOG_FILE_NAME="SuviBooster.log";
CONFIG_FILE_NAME="SuviBoosterConfig.sh";
LOCK_FILE_NAME="lock.pid";
#adb wait-for-device shell tail -f /data/SuviBoosterScript/SuviBooster.log
#cat /sys/devices/system/cpu/cpu0/cpufreq/stats/time_in_state


CLEAR_LOG_FILE_AFTER_NTH_EXECUTION="100";

#Temp variables
LOOP_COUNTER=0;
LOOP_MOD=0;
BATTERY_LEVEL=0;
BATTERY_STATUS="Suhas";
LOG_FILE="${SUVI_BASE_DIR}${LOG_FILE_NAME}";
LOCK_FILE="${SUVI_BASE_DIR}${LOCK_FILE_NAME}";
CONFIG_FILE="${SUVI_BASE_DIR}${CONFIG_FILE_NAME}";
TUNE2FS_EXEC="${SUVI_BASE_DIR}tune2fs";
SQLITE3_EXEC="${SUVI_BASE_DIR}sqlite3";

#####FUNCTIONS
writeLog()
{
	echo  "[$$][$( date +"%d-%m-%Y %r" )] $1" | tee -a "$LOG_FILE" &
}

clearLogFile()
{
	echo "" > "$LOG_FILE";
}

readConfigFile() 
{
	writeLog "Reading config file";
	. "$CONFIG_FILE";
	writeLog "Done reading config file";
}

#function to echo value to a file, redirect error to log file
#arg1: value
#arg2: file
setVal()
{
	writeLog "setting $2 = $1"
	echo "$1" > "$2";
}

#not used now!
#function to replace the value if its not the required.
#arg1 : the required value
#arg2 : the file to echo
setValIfDifferent()
{
	if [ -e "$2" ]; then
		EXISTING_VALUE=`cat "$2"`;
		if [ "$EXISTING_VALUE" != "$1" ]; then
			setVal "$1" "$2";
		#else
			#writeLog "not setting $2, it has $EXISTING_VALUE";
		fi;
	else
		writeLog "$2 not exists";
	fi;
}

#function to set value to file if it exists
#arg1 : the required value
#arg2 : the file to echo
setValIfExists()
{
	if [ -e "$2" ]; then
		setVal "$1" "$2";
	#else
		#writeLog "$2 not exists";
	fi;
}

#function to turn second core on/off instantly
secondCoreOnOff()
{
	if [ "$SECOND_CORE_ON_OFF" = "1" ]; then
		if [ -e "$SECOND_CORE_FILE" ]; then
			chmod 644 "$SECOND_CORE_FILE";
			setVal "$1" "$SECOND_CORE_FILE";
			chmod 444 "$SECOND_CORE_FILE";
			writeLog "Second core is now $1";
		else
			writeLog "second core - $SECOND_CORE_FILE not exists";
		fi;
	fi;
}

waitForWake()
{
	writeLog "Waiting for wake";
	AWAKE_STATE=`cat "$AWAKE_STATE_FILE"`;
	if [ "$AWAKE_STATE" != "awake" ]; then
		sleep $WAKE_SLEEP_CHECK_INTERVAL;
		waitForWake;
	fi;
}

waitForSleep()
{
	writeLog "Waiting for sleep";
	SLEEP_STATE=`cat "$SLEEP_STATE_FILE"`;
	if [ "$SLEEP_STATE" != "sleeping" ]; then
		sleep $WAKE_SLEEP_CHECK_INTERVAL;
		waitForSleep;
	fi;
}

applyAwakeSettings_inner()
{
	writeLog "Applying awake settings";
	secondCoreOnOff "1";
	
	setValIfExists "$GOVERNOR_CPU1" "$GOVERNOR_CPU1_FILE";
	setValIfExists "$MAX_FREQ_CPU1" "$MAX_FREQ_CPU1_FILE";
	#setValIfExists "$MIN_FREQ_CPU1" "$MIN_FREQ_CPU1_FILE";

	#Its observed that the second core CPU settings gets applied to first as well. Hence they should not be changed.
	#setValIfExists "$GOVERNOR_CPU2" "$GOVERNOR_CPU2_FILE";
	#setValIfExists "$MAX_FREQ_CPU2" "$MAX_FREQ_CPU2_FILE";
	#setValIfExists "$MIN_FREQ_CPU2" "$MIN_FREQ_CPU2_FILE";
	writeLog "Done applying awake settings";
}

applyAwakeSettings()
{
	if [ "$CONSIDER_BATTERY_STATUS" = "1" ]; then
		BATTERY_STATUS=`cat "$BATTERY_STATE_FILE"`;
		BATTERY_LEVEL=`cat "$BATTERY_CAPACITY_FILE"`;
		#writeLog "Battery Status = $BATTERY_STATUS"
		if [ "$BATTERY_STATUS" = "$BATTERY_STATE_DISCHARGING" ] && [ "$BATTERY_LEVEL" -le "$BATTERY_MIN_LIMIT" ]; then
			writeLog "Awake settings are not applied - Battery is below $BATTERY_MIN_LIMIT % and not charging";
		else
			applyAwakeSettings_inner;
		fi;
	else
		applyAwakeSettings_inner;
	fi;
}

applySleepSettings_inner()
{
	writeLog "Applying sleep settings";
	setValIfExists "$SLEEP_GOVERNOR_CPU1" "$GOVERNOR_CPU1_FILE";
	setValIfExists "$SLEEP_MAX_FREQ_CPU1" "$MAX_FREQ_CPU1_FILE";
	#setValIfExists "$SLEEP_MIN_FREQ_CPU1" "$MIN_FREQ_CPU1_FILE";

	#Its observed that the second core CPU settings gets applied to first as well. Hence they should not be changed.
	#setValIfExists "$SLEEP_GOVERNOR_CPU2" "$GOVERNOR_CPU2_FILE";
	#setValIfExists "$SLEEP_MAX_FREQ_CPU2" "$MAX_FREQ_CPU2_FILE";
	#setValIfExists "$SLEEP_MIN_FREQ_CPU2" "$MIN_FREQ_CPU2_FILE";
	
	secondCoreOnOff "0";
	writeLog "Done applying sleep settings";
}

applySleepSettings()
{
	if [ "$CONSIDER_BATTERY_STATUS" = "1" ]; then
		BATTERY_STATUS=`cat "$BATTERY_STATE_FILE"`;
		#writeLog "Battery Status = $BATTERY_STATUS";
		if [ "$BATTERY_STATUS" = "$BATTERY_STATE_CHARGING" ]; then
			writeLog "Sleep settings are not applied - Battery is charging";
		else
			applySleepSettings_inner;
		fi;
	else
		applySleepSettings_inner;
	fi;
}

singleInstanceCheck()
{
	#write PID to lock file. Wait for some time and check again if my pid = PID in file.
	#If someone else written PID in the file, let him run, exit.
	setVal $$ "$LOCK_FILE";
	if [ $? != 0 ]; then
		writeLog "Error: failed to create LOCK_FILE. Exiting now";
		exit 1;
	fi;
	chmod 777 "$LOCK_FILE";
	
	sleep 2;
	PID=`cat "$LOCK_FILE"`;
	if [ $$ != $PID ]; then
		writeLog "Error: My PID $$ is different than PID in lock file ${PID}. Exiting now to prevent parallel execution";
		exit 1;
	fi;
	#writeLog "START_SCRIPT $$";
}

otherTweaks()
{
	# Remount all partitions with noatime
	# perfect mount options
	busybox mount -o remount,noatime,noauto_da_alloc,nodiratime,barrier=0,nobh /system
	busybox mount -o remount,noatime,noauto_da_alloc,nosuid,nodev,nodiratime,barrier=0,nobh /data
	busybox mount -o remount,noatime,noauto_da_alloc,nosuid,nodev,nodiratime,barrier=0,nobh /cache

	# Tweak kernel VM management
	#setValIfExists "0" "/proc/sys/vm/swappiness";
	setValIfExists "90" "/proc/sys/vm/dirty_ratio";
	setValIfExists "4096" "/proc/sys/vm/min_free_kbytes";

	# Tweak kernel scheduler, less aggressive settings
	setValIfExists "18000000" "/proc/sys/kernel/sched_latency_ns";
	setValIfExists "3000000" "/proc/sys/kernel/sched_wakeup_granularity_ns";
	setValIfExists "1500000" "/proc/sys/kernel/sched_min_granularity_ns";

	# Misc tweaks for battery life
	setValIfExists "2000" "/proc/sys/vm/dirty_writeback_centisecs";
	setValIfExists "1000" "/proc/sys/vm/dirty_expire_centisecs";


	setValIfExists "0" "/proc/sys/vm/oom_kill_allocating_task";
	setValIfExists "0" "/proc/sys/vm/panic_on_oom";
	setValIfExists "0" "/proc/sys/vm/laptop_mode";
	setValIfExists "50" "/proc/sys/vm/vfs_cache_pressure";
	setValIfExists "70" "/proc/sys/vm/dirty_background_ratio";

	setValIfExists "8" "/proc/sys/vm/page-cluster";
	setValIfExists "64000" "/proc/sys/kernel/msgmni";
	setValIfExists "64000" "/proc/sys/kernel/msgmax";
	setValIfExists "10" "/proc/sys/fs/lease-break-time";
	setValIfExists "500,512000,64,2048" "/proc/sys/kernel/sem";

	#EXT4 tweaks (greatly increase I/O)
	#removes journalism
	$TUNE2FS_EXEC -o journal_data_writeback /block/path/to/system
	$TUNE2FS_EXEC -O ^has_journal /block/path/to/system
	$TUNE2FS_EXEC -o journal_data_writeback /block/path/to/cache
	$TUNE2FS_EXEC -O ^has_journal /block/path/to/cache
	$TUNE2FS_EXEC -o journal_data_writeback /block/path/to/data
	$TUNE2FS_EXEC -O ^has_journal /block/path/to/data

	#Defrags database files
	for i in `find /data -iname "*.db"`;
	do
	$SQLITE3_EXEC "$i" 'VACUUM;'; 
	done;
	
	#Disable normalize sleeper
	mount -t debugfs none "/sys/kernel/debug";
	setValIfExists "NO_NORMALIZED_SLEEPER" "/sys/kernel/debug/sched_features";
}

setReadAheadKb()
{
	writeLog "Setting IO_SCHED=$IO_SCHED and READAHEAD_KB=$READAHEAD_KB, disable iostats";
	MMC=`ls -d $MMC_FILES`;
	for q in $MMC; do
		setValIfExists "$IO_SCHED" "$q/queue/scheduler";
		setValIfExists "0" "$q/queue/iostats";
		setValIfExists "$READAHEAD_KB" "$q/queue/read_ahead_kb";
		setValIfExists "0" "$q/queue/rotational";
		setValIfExists "$READAHEAD_KB" "$q/queue/nr_requests";
	done;

	MMC=`ls -d $BDI_FILES`;
	for q in $MMC; do
		setValIfExists "$READAHEAD_KB" "$q/read_ahead_kb";
	done;
	writeLog "Done setting IO_SCHED=$IO_SCHED and READAHEAD_KB=$READAHEAD_KB, disable iostats";
}

setLeaseBreakTime()
{
	writeLog "Setting lease break time";
	setValIfExists "10" "/proc/sys/fs/lease-break-time";
	writeLog "Done setting lease break time";
}

chmodRequiredFiles()
{
	writeLog "chmod-ing required files";
	chmod 777 "$MIN_FREQ_CPU1_FILE";
	#chmod 777 "$MIN_FREQ_CPU2_FILE";
	chmod 777 "$MAX_FREQ_CPU1_FILE";
	#chmod 777 "$MAX_FREQ_CPU2_FILE";
	chmod 777 "$GOVERNOR_CPU1_FILE";
	#chmod 777 "$GOVERNOR_CPU2_FILE";
	chmod 777 "$SECOND_CORE_FILE";
	chmod 777 "$ADJ_PARAMS_FILE";
	chmod 777 "$MINFREE_FILE";
	chmod 777 "$BATTERY_STATE_FILE";
	chmod 777 "$BATTERY_CAPACITY_FILE";
	writeLog "Done chmod-ing required files";
}

setADJAndMinfree()
{
	writeLog  "Setting ADJ_PARAMS=$ADJ_PARAMS, MINFREE_PARAMS=$MINFREE_PARAMS";
	setValIfExists "$ADJ_PARAMS" "$ADJ_PARAMS_FILE";
	setValIfExists "$MINFREE_PARAMS" "$MINFREE_FILE";
	writeLog  "Done setting ADJ_PARAMS=$ADJ_PARAMS, MINFREE_PARAMS=$MINFREE_PARAMS";
}

clearLogFileIfRequired()
{
	writeLog "LOOP_COUNTER=$LOOP_COUNTER, log file will be cleared if LOOP_COUNTER is in multiples of $CLEAR_LOG_FILE_AFTER_NTH_EXECUTION"
	LOOP_COUNTER=$(($LOOP_COUNTER+1));
	#Clear the log file on every CLEAR_LOG_FILE_AFTER_NTH_EXECUTION th execution of loop.
	LOOP_MOD=$(($LOOP_COUNTER%$CLEAR_LOG_FILE_AFTER_NTH_EXECUTION));
	if [ "$LOOP_MOD" = "0" ]; then
		clearLogFile;
	fi;
}

reReadConfigFileIfRequired()
{
	if [ "$CONFIG_READ_ONE_TIME" = "0" ]; then
		readConfigFile;
	fi;
}

#Script starts here
exec 2>> "$LOG_FILE";

singleInstanceCheck;

clearLogFile;

writeLog "SuviBooster Script started";

readConfigFile;

chmodRequiredFiles;

setReadAheadKb;

setLeaseBreakTime;

otherTweaks;

setADJAndMinfree;

writeLog  "CPU Configuration : GOVERNOR_CPU1=$GOVERNOR_CPU1, MAX_FREQ_CPU1=$MAX_FREQ_CPU1, MIN_FREQ_CPU1=$MIN_FREQ_CPU1, SLEEP_GOVERNOR_CPU1=$SLEEP_GOVERNOR_CPU1, SLEEP_MAX_FREQ_CPU1=$SLEEP_MAX_FREQ_CPU1, SLEEP_MIN_FREQ_CPU1=$SLEEP_MIN_FREQ_CPU1";

applyAwakeSettings;
setValIfExists "$MIN_FREQ_CPU1" "$MIN_FREQ_CPU1_FILE";
#setValIfExists "$MIN_FREQ_CPU2" "$MIN_FREQ_CPU2_FILE";

#Infinite loop for CPU freq on wake and sleep states
while [ 1 ]  
do 
	clearLogFileIfRequired;
	
	waitForWake;

	reReadConfigFileIfRequired;
	
	applyAwakeSettings;
	
	sleep $WAKE_SLEEP_CHECK_INTERVAL;
	
	waitForSleep;
	
	applySleepSettings;
	
	#sleep $WAKE_SLEEP_CHECK_INTERVAL

done;