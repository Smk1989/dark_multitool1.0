#!/system/bin/sh
#Suvi Booster Script config file
#Users are free to use this but ROM developers please DO NOT include this in your ROM
#Dont forget to say thanks to bsuhas here http://forum.xda-developers.com/showthread.php?t=2499051

#The default settings here are suitable for Micromax A110 (which I have) - dual core 1GHz, 512MB RAM
#Please change values if you have any other device

#When screen is ON/Awake
GOVERNOR_CPU1="ondemand";
MAX_FREQ_CPU1="1001000";
MIN_FREQ_CPU1="250250";

#When screen is OFF/Sleep
SLEEP_GOVERNOR_CPU1="powersave";
SLEEP_MAX_FREQ_CPU1="667333";
SLEEP_MIN_FREQ_CPU1="250250";

#IO Schedular
IO_SCHED="cfq";

############################ ADVANCED USERS ONLY ########################################
#Advanced properties below. Do not touch if you dont know them

#Recomended to be "1" for dual core devices however, set to "0" if you don't want the script to turn the second core on/off
#Set to "0" for single core devices
SECOND_CORE_ON_OFF="1";

#Consider the battery status in the script. like -
#When charging, don't apply sleep setting freq and governors. 
#When battery is below 15 (see the BATTERY_MIN_LIMIT below) do not apply awake freq and governors
#Set it to 0 if you want the script to ignore the battery status
CONSIDER_BATTERY_STATUS="0";

#Memory mgmt
ADJ_PARAMS="0,1,2,4,7,15";
MINFREE_PARAMS="2048,4096,8192,16384,24576,32768";
READAHEAD_KB="1024";

#Read this file only one time (at boot) (="1") or every time device wakes up (="0")
#Recommended to be "1". If you are trying out different configuration and want it to be applied without reboot then set to "0"
CONFIG_READ_ONE_TIME="1";

#Interval in seconds for script to pause when checking device is awake or sleep.
#This interval will not matter much. Recommended not to change
WAKE_SLEEP_CHECK_INTERVAL="20";

#The minimum battery percentage below which the battery saving profile is applied
BATTERY_MIN_LIMIT="15";